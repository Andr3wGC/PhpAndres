<html>

<body>
    <h1>INICIO  </h1>
    <!-- Links a las otras paginas -->
    <a href="pe_altaped.php">1. Realizar pedidos </a><br><br>
    <a href="pe_consped.php">2. Consulta de pedidos </a><br><br>
    <a href="pe_consprodstock.php">3. Consultar stock </a><br><br>
    <a href="pe_constock.php">4. Consulta de stock por lineas </a><br><br>
    <a href="pe_conspago.php">5. Consultar compras realizadas </a><br><br>
    <a href="pe_topprod.php">6. Consultar compras realizadas por cliente </a><br><br>
    

</body>

</html>